package rec.ui;

import java.util.Scanner;

import rec.bean.RechargedemoBean;
import rec.exception.RechargedemoException;
import rec.service.IRechargedemoService;
import rec.service.RechargedemoService;

public class RechargedemoMain 

{
	static Scanner sc=null;
	public static void main(String[] args) throws RechargedemoException 
	{
		sc=new Scanner(System.in);
		String planname=null;
		String rstatus=null;
		
		
		System.out.println("===================================");
		System.out.println("    Welcome to Recharge Service");
		System.out.println("===================================");
		System.out.println("1.recharge balance");
		System.out.println("2.exit");
		System.out.println("Enter your option");
		
		int choice=sc.nextInt();
		switch (choice) 
		{
		case 1:int amount;
		      
			  IRechargedemoService rservice=new RechargedemoService();
			    System.out.println("Enter your name");
			    String name=sc.next();
			    System.out.println("Enter your mobile number");
			    String mobnum=sc.next();
			    
			      do
			    	{
			    	System.out.println("Enter amount[99,199,299]");
			        amount=sc.nextInt();
			        planname=validateamount(amount);
			        System.out.println(planname);
			        if(planname!=null)
			        {
			        	rstatus="Recharged";
			        }
			        
			    
			    	}while(planname==null);
			    
			      
			      RechargedemoBean rb=new RechargedemoBean(name, mobnum, amount, planname, rstatus);
			    int result=0;
			    result=addDetails(rb);
			    
			    
			    int rechid=0;
			    rechid=rechargedemo(rb);
			    if(rechid>0)
			    {
			    	System.out.println("recharged successfully and recharge id is"+rechid);
			    }
			    else
			    {
			    	System.out.println("details are not stored");
			    }
		
			break;

		default:
			break;
		}
		
	}

	private static int rechargedemo(RechargedemoBean rb) throws RechargedemoException {
		IRechargedemoService rservice=new RechargedemoService();
		return rservice.storerechargeid(rb);
	}

	private static String validateamount(int amount) {
		IRechargedemoService rservice=new RechargedemoService();
		return rservice.validateamount(amount);
	}

	private static int addDetails(RechargedemoBean rb) throws RechargedemoException 
	{
		IRechargedemoService rservice=new RechargedemoService();
		return rservice.storeDetails(rb);
	}
	
	

}

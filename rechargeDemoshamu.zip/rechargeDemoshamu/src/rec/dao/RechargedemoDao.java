package rec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import rec.bean.RechargedemoBean;
import rec.exception.RechargedemoException;
import rec.util.DbUtility;

public class RechargedemoDao implements IRechargedemoDao {

	Connection conn=null;
	@Override
	public int storeDetails(RechargedemoBean rb) throws RechargedemoException
	{
		int status=0;
		int rechid=0;
		conn=DbUtility.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RECHARGEDEMO_INSERT_QRY);
			pst.setString(1, rb.getName());
			pst.setString(2, rb.getMobnum());
			pst.setInt(3, rb.getAmount());
			pst.setString(4, rb.getPlanname());
			
			pst.setString(5, rb.getStatus());
			status=pst.executeUpdate();
			pst=conn.prepareStatement(IQueryMapper.SELECT_RECHARGEDEMO_ID);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				rechid=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			throw new RechargedemoException("data not stored "+e.getMessage());
		}
		
		return rechid;
	}
	@Override
	public int storerechargeid(RechargedemoBean rb) throws RechargedemoException {
		int status=0,rechid=0;
		conn=DbUtility.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RECHARGE_SELECT_QRY);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				rechid=rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new RechargedemoException("data not stored "+e.getMessage());
		}
		return rechid;
	}

}

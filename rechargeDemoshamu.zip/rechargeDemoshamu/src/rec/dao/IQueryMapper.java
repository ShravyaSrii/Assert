package rec.dao;

public interface IQueryMapper 
{
	public static final String RECHARGEDEMO_INSERT_QRY="insert into rechargedemo values(rec_seq1.NEXTVAL,?,?,?,?,SYSDATE,?)";
	public static final String SELECT_RECHARGEDEMO_ID="SELECT rec_seq1.CURRVAL FROM DUAL";
	public static final String RECHARGE_SELECT_QRY="SELECT rechid FROM rechargedemo";

}
	
	